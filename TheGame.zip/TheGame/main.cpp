#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <list>
#include "view.h"
#include <cmath>

#include <tmxlite/Map.hpp>
#include <tmxlite/Layer.hpp>
#include <tmxlite/TileLayer.hpp>
#include <tmxlite/ObjectGroup.hpp>
#include <tmxlite/LayerGroup.hpp>
#include "parse.h"
#include "SFMLOrthogonalLayer.h"

#include "Level.h"

using namespace std;
using namespace sf;
using namespace tmx;

class Entity {
private:
	
public:
	Image image;
	Texture texture;
	bool life;
	std::vector<Object> obj;
	float speed, speedX, speedY;
	float width, height;
	float x, y;
	bool isMove;
	Sprite sprite;
	string name;
	Entity(Image &image, string Name, float X, float Y, float W, float H) {
		x = X, y = Y;
		width = W, height = H;
		life = true;
		name = Name;
		speed = 0, speedX = 0, speedY = 0;
		isMove = false;
		texture.loadFromImage(image);
		sprite.setTexture(texture);
		sprite.setPosition(x, y);
		sprite.setOrigin(width / 2, height / 2);
	}

	void setPosition(float X, float Y) {
		x = X, y = Y;
		sprite.setPosition(x, y);
	}

	void rotate(float X, float Y) {
		float dX = X - x;
		float dY = Y - y;
		float rotation = (atan2(dY, dX)) * 180 / 3.14159265;
		sprite.setRotation(rotation);
	}

	sf::FloatRect getRect() {//�-��� ��������� ��������������. ��� �����,������� (���,�����).
		return sf::FloatRect(x, y, width, height);//��� �-��� ����� ��� �������� ������������ 
	}

	virtual void update(float time) = 0;
};


class Person : public Entity {
private:
	Texture legsTexture;
	float dt;
public:
	float shootTime;
	float isShoot;
	float legsTime;
	float shootX, shootY;
	const float personSpeed = 0.2;
	Sprite legsSprite;
	Person(Image& personImage, Image& LegsImage, string Name, Level& lev, float X, float Y, float W, float H) : Entity(personImage, Name, X, Y, W, H) {

		legsTime = 0;
		shootTime = 0;
		dt = 75;
		isShoot = false;
		legsTexture.loadFromImage(LegsImage);
		legsSprite.setTexture(legsTexture);
		legsSprite.setTextureRect(sf::IntRect(0, 0, 32, 32));
		legsSprite.setScale(2, 2);
		legsSprite.setOrigin(16, 16);
	}

	void updateLegs() {
		if (isMove) {
			if (legsTime >= dt * 16 || isMove == false) legsTime = 0;
			legsSprite.setTextureRect(sf::IntRect(32 * (int(legsTime / dt)) + 1, 0, 32, 32));
		}
		else {
			legsSprite.setTextureRect(sf::IntRect(0, 0, 32, 32));
		}
		legsSprite.setPosition(x + width / 2, y + height / 2);
	}

	void rotate(float X, float Y) {
		if (life) {
			float dX = X - x;
			float dY = Y - y;
			float rotation = (atan2(dY, dX)) * 180 / 3.14159265;
			sprite.setRotation(rotation);
			legsSprite.setRotation(rotation);
		}
	}

	void stopInFront(sf::FloatRect obj, float Dx, float Dy) {
		if (Dy > 0) { y = obj.top - height; speedY = 0; }
		if (Dy < 0) { y = obj.top + obj.height; speedY = 0; }
		if (Dx > 0) { x = obj.left - width; }
		if (Dx < 0) { x = obj.left + obj.width; }
	}

	void checkCollisionWithMap(float Dx, float Dy) {
		for (int i = 0; i < obj.size(); i++) {
			if (getRect().intersects(sf::FloatRect(obj[i].getAABB().left, obj[i].getAABB().top, obj[i].getAABB().width, obj[i].getAABB().height)))//��������� ����������� ������ � ��������
			{
				if (obj[i].getName() == "solid")//���� ��������� �����������
				{
					tmx::FloatRect tmxRect = obj[i].getAABB();
					stopInFront(sf::FloatRect(tmxRect.left, tmxRect.top, tmxRect.width, tmxRect.height), Dx, Dy);
				}
			}
		}
	}

	void move(float tempX, float tempY, float time) {
		if (isMove) {
			float distance = sqrt((tempX - x) * (tempX - x) + (tempY - y) * (tempY - y));
			float tempSpeedX, tempSpeedY;
			if (distance > 2) {
				tempSpeedX = 0.1 * (tempX - x) / distance;
				tempSpeedY = 0.1 * (tempY - y) / distance;
				x += tempSpeedX * time;
				y += tempSpeedY * time;
				//checkCollisionWithMap(tempSpeedX, tempSpeedY);
			}
			else { isMove = false; }
		}
	}

	void setDeadSprite(float angle) {
		image.loadFromFile("images/killed_person.png");
		texture.loadFromImage(image);
		isMove = false;
		sprite.setTexture(texture);
		sprite.setPosition(x, y);
		width = 60;
		height = 32;
		sprite.setOrigin(width / 2, height / 2);
		sprite.setRotation(angle);
		sprite.setTextureRect(sf::IntRect(0, 0, 60, 32));
	}

	void updateSprite() {
		float shootDt = dt + 5;
		if (isShoot) {
			int i = int(shootTime / shootDt);
			if (shootTime >= shootDt * 12) { shootTime = 0; isShoot = false; return; };
			if (i < 2) {
				sprite.setTextureRect(sf::IntRect(2 + i * 42, 8, 42, 18));
			}
			else {
				sprite.setTextureRect(sf::IntRect(91 + (12 + 32) * (i - 2), 8, 32, 18));
			}
		}
	}

	void shoot() {
		isShoot = true;
		shootTime = 0;
		shootX = x;
		shootY = y;
	}
	
};


class Player : public Person{
private:
	float playerSpeed = personSpeed;
	enum { left, right, up, down, stay, right_up, right_down, left_up, left_down } state;
public:
	Player(Image &playerImage, Image &LegsImage, string Name, Level& lev, float X, float Y, float W, float H) : Person(playerImage, LegsImage, Name, lev, X, Y, W, H) {
		state = stay;
		sprite.setTextureRect(sf::IntRect(90, 8, width, height));
		obj = lev.GetAllObjects();
		sprite.setScale(2, 2);
	}

	void control() {
		state = stay;
		if (Keyboard::isKeyPressed) {
			if (Keyboard::isKeyPressed(Keyboard::A)) {
				state = left; speed = playerSpeed;
			}
			if (Keyboard::isKeyPressed(Keyboard::D)) {
				state = right; speed = playerSpeed;
			}
			if (Keyboard::isKeyPressed(Keyboard::W)) {
				state = up; speed = playerSpeed;
			} 
			if (Keyboard::isKeyPressed(Keyboard::S)) {
				state = down; speed = playerSpeed;
			}
			if (Keyboard::isKeyPressed(Keyboard::S) && Keyboard::isKeyPressed(Keyboard::D)) {
				state = right_down; speed = playerSpeed;
			}
			if (Keyboard::isKeyPressed(Keyboard::W) && Keyboard::isKeyPressed(Keyboard::D)) {
				state = right_up; speed = playerSpeed;
			}
			if (Keyboard::isKeyPressed(Keyboard::W) && Keyboard::isKeyPressed(Keyboard::A)) {
				state = left_up; speed = playerSpeed;
			}
			if (Keyboard::isKeyPressed(Keyboard::S) && Keyboard::isKeyPressed(Keyboard::A)) {
				state = left_down; speed = playerSpeed;
			}
		}
	}

	void update(float time) {
		if (life) {
			control();
			switch (state)
			{
			case right: speedX = speed; speedY = 0; isMove = true; break;
			case left: speedX = -speed; speedY = 0; isMove = true; break;
			case up: speedY = -speed; speedX = 0; isMove = true; break;
			case down: speedY = speed; speedX = 0; isMove = true; break;
			case left_up: speedY = -speed; speedX = -speed; isMove = true; break;
			case left_down: speedY = speed; speedX = -speed; isMove = true; break;
			case right_up: speedY = -speed; speedX = speed; isMove = true; break;
			case right_down: speedY = speed; speedX = speed; isMove = true; break;
			case stay: speedX = speedY = speed = 0; isMove = false; break;
			}
			x += speedX * time;
			checkCollisionWithMap(speedX, 0);
			y += speedY * time;
			checkCollisionWithMap(0, speedY);
			if (!isMove) speed = 0;
			sprite.setPosition(x + width / 2, y + height / 2);
			setPlayerCoordinateForView(x, y);
			legsTime += time;
			updateSprite();
			if (isShoot) {
				shootTime += time;
			}
			updateLegs();
		}
	}

	void checkCollisionWithMap(float Dx, float Dy) {
		for (int i = 0; i < obj.size(); i++) {
			if (getRect().intersects(sf::FloatRect(obj[i].getAABB().left, obj[i].getAABB().top, obj[i].getAABB().width, obj[i].getAABB().height)))//��������� ����������� ������ � ��������
			{
				if (obj[i].getName() == "solid")//���� ��������� �����������
				{
					tmx::FloatRect tmxRect = obj[i].getAABB();
					stopInFront(sf::FloatRect(tmxRect.left, tmxRect.top, tmxRect.width, tmxRect.height), Dx, Dy);
				}
			}
		}
	}
};


class Enemy : public Person {
private:
	vector <tmx::Object> tracks;
	float trackId;
public:
	int num;
	Enemy(Image& image, Image& LegsImage, String Name, Level& lvl, float X, float Y, int W, int H, int Num) : Person(image, LegsImage, Name, lvl, X, Y, W, H) {
		num = Num;
		isMove = false;
		trackId = 0;
		obj = lvl.GetObjects("solid");
		tracks = lvl.GetObjectsWithType("track");
		if (name == "Enemy") {
			sprite.setTextureRect(sf::IntRect(90, 8, width, height));
			sprite.setScale(2, 2);
		}
	}

	void go(float time) {
		float tempX = tracks[trackId].getPosition().x;
		float tempY = tracks[trackId].getPosition().y;
		move(tempX, tempY, time);
		rotate(tempX, tempY);
		if (sqrt((tempX - x) * (tempX - x) + (tempY - y) * (tempY - y)) <= 2) {
			trackId++;
		}
		if (trackId == tracks.size()) trackId = 0;
	}

	void goToCoords(float X, float Y, float time) {
		move(X, Y, time);
		rotate(X, Y);
	}

	void update(float time)
	{
		if (life) {
			if (name == "Enemy") {
				legsTime += time;
				if (isShoot)
					shootTime += time;
				updateLegs();
				updateSprite();
				sprite.setPosition(x + width / 2, y + height / 2);
				checkCollisionWithMap(speedX, speedY);
			}
		}
	}

	sf::RectangleShape getEnemyView() {
		sf::FloatRect rect(x + 20, y, width + 300, height + 150);
		sf::RectangleShape sh(sf::Vector2f(rect.width, rect.height));
		sh.setFillColor(Color(255, 255, 255));
		sh.setOrigin(0, rect.height / 2);
		sh.setPosition(rect.left, rect.top);
		sh.setRotation(sprite.getRotation());
		return sh;
	}
};


class Bullet : public Entity{
private:
	float bullet_speed;
	float targetX, targetY, distance;
	float vx, vy;
public:
	int num;
	float fromX, fromY;
	Bullet(Image& image, string Name, Level &lvl, float X, float Y, float W, float H, float tX, float tY, int Num) : Entity(image, Name, X, Y, W, H) {
		num = Num;
		life = true;
		obj = lvl.GetObjects("solid");
		sprite.setTextureRect(sf::IntRect(0, 0, width, height));
		bullet_speed = 2;
		targetX = tX;
		targetY = tY;
		fromX = X, fromY = Y;
		distance = sqrt((targetX - x)*(targetX - x) + (targetY - y)*(targetY - y));
		vx = (targetX - x) / distance;
		vy = (targetY - y) / distance;
		rotate(targetX, targetY);
	}

	void update(float time)
	{
		x += vx * time * bullet_speed;
		y += vy * time * bullet_speed;
		if (x <= 0) x = 1;
		if (y <= 0) y = 1;
		for (int i = 0; i < obj.size(); i++) {
			if (getRect().intersects(sf::FloatRect(obj[i].getAABB().left, obj[i].getAABB().top, obj[i].getAABB().width, obj[i].getAABB().height)))
			{
				life = false;
			}
		}
		sprite.setPosition(x + width / 2, y + height / 2);
	}
};


class Aim : public Entity {
private:
public:
	Aim(Image& image, string Name, float X, float Y, float W, float H) : Entity(image, Name, X, Y, W, H) {
		image.createMaskFromColor(Color(255, 255, 255));
	}

	void update(float time) {}
};


void updateList(std::list<Entity*>::iterator it, std::list<Entity*> &entities, float time) {
	for (it = entities.begin(); it != entities.end();) {
		Entity* b = *it;
		b->update(time);
		if (b->life == false) {
			it = entities.erase(it);
			delete b;
		}
		else it++;
	}
}

void drawList(std::list<Entity*>::iterator it, std::list<Entity*> entities, RenderWindow &window) {
	for (it = entities.begin(); it != entities.end(); it++) { window.draw((*it)->sprite); }
}

float getDistance(float tempX, float tempY, float x, float y) {
	float distance = sqrt((tempX - x) * (tempX - x) + (tempY - y) * (tempY - y));
	return distance;
}

int main() {
	parse("map.tmx");
	RenderWindow window(VideoMode(1380, 720), "Game");
	window.setMouseCursorVisible(false);
	view.reset(sf::FloatRect(0, 0, 1380, 720));

	Level lvl("map.tmx");
	MapLayer layer0(lvl.map, 0);
	MapLayer layer1(lvl.map, 1);
	MapLayer layer2(lvl.map, 2);

	std::list<Entity*> enemies;
	std::list<Entity*>::iterator it;
	std::list<Entity*>::iterator it2;
	std::list<Entity*> bullets;

	Image aimImage;
	aimImage.loadFromFile("images/aim.png");
	Aim aim(aimImage, "Aim", 0, 0, 52, 52);

	sf::Sound shootSound;
	sf::SoundBuffer soundBuffer;
	soundBuffer.loadFromFile("audio/shoot.ogg");
	shootSound.setBuffer(soundBuffer);
	

	Image playerImage, legsImage;
	playerImage.loadFromFile("images/player.png");
	legsImage.loadFromFile("images/legs.png");
	Object playerObj = lvl.GetObject("player");
	Player player(playerImage, legsImage, "Player", lvl, playerObj.getAABB().left, playerObj.getAABB().top, 32, 18);

	Image bulletImage;
	bulletImage.loadFromFile("images/bullet_tr2.png");
	
	vector <Object> enemiesObj = lvl.GetObjects("enemy");
	for (int i = 0; i < enemiesObj.size(); i++) {
		enemies.push_back(new Enemy(playerImage, legsImage, "Enemy", lvl, enemiesObj[i].getAABB().left, enemiesObj[i].getAABB().top, 32, 18, i));
	}
	
	sf::Vector2i pixelPos;
	sf::Vector2f pos;
	float aimPosX, aimPosY;
	Clock clock;
	float dt = 70; float angle = -60;
	while (window.isOpen()) {
		float time = clock.getElapsedTime().asMicroseconds();
		clock.restart();
		time = time / 800;

		pixelPos = Mouse::getPosition(window);
		pos = window.mapPixelToCoords(pixelPos);
		aim.setPosition(pos.x, pos.y);
		Event event;

		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed)
				window.close();
			if (event.type == Event::MouseButtonPressed) {
				if (event.key.code == Mouse::Left && player.life) {
					bullets.push_back(new Bullet(bulletImage, "Bullet", lvl, player.x, player.y, 16, 16, aim.x, aim.y, -1));
					player.shoot();
					//shootSound.play();
				}
			}
		}
		sf::FloatRect rect;
		sf::RectangleShape sh;
		int i = 0;
		for (it = enemies.begin(); it != enemies.end(); it++) {
			Enemy* enemy = (Enemy*)(*it);
			if (enemy->life) {
				for (it2 = bullets.begin(); it2 != bullets.end(); it2++) {
					Bullet* bullet = (Bullet*)(*it2);
					// �������� �����
					if (enemy->getRect().intersects(bullet->getRect())) {
						if (enemy->num != bullet->num) {
							enemy->life = false;
							bullet->life = false;
							enemy->setDeadSprite(bullet->sprite.getRotation());
						}
					}
					// �������� ������
					if (player.getRect().intersects(bullet->getRect())) {
						if (bullet->num != -1) {
							player.life = false;
							bullet->life = false;
							player.setDeadSprite(bullet->sprite.getRotation());
						}
					}
				}
				if (enemy->getRect().intersects(player.getRect())) {
					player.stopInFront(enemy->getRect(), player.speedX, player.speedY);
				}
				// ������ �����
				rect.left = enemy->x; rect.top = enemy->y; rect.width = 300; rect.height = 2;// (enemy->x, enemy->y, 300, 2);
				sh.setSize(sf::Vector2f(rect.width, rect.height));
				sh.setFillColor(Color(255, 255, 255));
				sh.setPosition(rect.left, rect.top);
				bool seeYa = false, barrier = false;
				//for (int angle = -60; angle <= 60; angle++) {
					sh.setRotation(enemy->sprite.getRotation() + angle);
					if (sh.getGlobalBounds().intersects(player.getRect()) && player.life) {
						seeYa = true;
						float minSolidDistance = 2 ^ 1000;
						for (const auto& solid : lvl.GetObjects("solid")) {
							sf::FloatRect solidRect(solid.getAABB().left, solid.getAABB().top, solid.getAABB().width, solid.getAABB().height);
							if (sh.getGlobalBounds().intersects(solidRect)) {
								float destToSolid = getDistance(enemy->x, enemy->y, solid.getAABB().left, solid.getAABB().top);
								if (destToSolid < minSolidDistance)
									minSolidDistance = destToSolid;
							}
						}
						float destToPlayer = getDistance(enemy->x, enemy->y, player.x, player.y);
						if (minSolidDistance < destToPlayer) {
							barrier = true;
						}
						else {
							cout << "coords: " << minSolidDistance << " " << destToPlayer << " " << angle << endl;
							barrier = false;
						}
					}
					angle++;
					if (angle >= 60) angle = -60;
				//}
				// ��������� ���� �� ������
				if (!barrier && seeYa) {
					enemy->isMove = true;
					enemy->goToCoords(player.x, player.y, time);
					if (!enemy->isShoot) {
						bullets.push_back(new Bullet(bulletImage, "Bullet", lvl, enemy->x, enemy->y, 16, 16, player.x, player.y, i));
						enemy->shoot();
						//shootSound.play();
					}
				}
				// ��������� ���� �� ��������� ����
				if (!seeYa || barrier) {
					enemy->isMove = true;
					enemy->go(time);
				}
			}
			i++;
		}

		//updateList(it, enemies, time);
		for (it = enemies.begin(); it != enemies.end(); it++) {
			(*it)->update(time);
		}
		updateList(it, bullets, time);
		

		player.rotate(aim.x, aim.y);
		player.update(time);

		window.setView(view);
		window.clear(Color(130, 137, 150));
		window.draw(layer0);
		window.draw(layer1);
		window.draw(layer2);
		
		for (it = enemies.begin(); it != enemies.end(); it++) {
			Enemy* enemy = (Enemy*)*it;
			if(enemy->life)
				window.draw(enemy->legsSprite);
			window.draw(enemy->sprite);
			
			window.draw(sh);
			//window.draw(enemy->getEnemyView());
		}
		if (player.life)
			window.draw(player.legsSprite);
		window.draw(player.sprite);
		drawList(it, bullets, window);
		window.draw(aim.sprite);

		window.display();
	}
	return 0;
}