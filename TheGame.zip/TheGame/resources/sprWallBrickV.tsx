<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="sprWallBrickV" tilewidth="8" tileheight="32" tilecount="1" columns="1">
 <image source="assets/Walls/sprWallBrickV.png" width="8" height="32"/>
</tileset>
