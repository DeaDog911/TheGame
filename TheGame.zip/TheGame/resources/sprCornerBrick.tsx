<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.4" name="sprCornerBrick" tilewidth="16" tileheight="16" tilecount="9" columns="3">
 <image source="assets/Walls/sprCornerBrick.png" width="60" height="60"/>
</tileset>
